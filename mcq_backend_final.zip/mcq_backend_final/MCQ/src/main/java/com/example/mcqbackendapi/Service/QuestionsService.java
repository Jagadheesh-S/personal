package com.example.mcqbackendapi.Service;


import com.example.mcqbackendapi.Entity.Options;
import com.example.mcqbackendapi.Entity.Questions;
import com.example.mcqbackendapi.Entity.TopicSubCategory;
import com.example.mcqbackendapi.Repository.QuestionsRepository;
import com.example.mcqbackendapi.Repository.TopicSubCategoryRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.transaction.Transactional;
import java.security.spec.KeySpec;
import java.util.*;

@Service
public class QuestionsService {
    @Autowired
    private QuestionsRepository questionsRepository;

    @Autowired
    private TopicSubCategoryRepository topicSubCategoryRepository;

    public Questions addQuestion(Questions question){
        return questionsRepository.save(question);
    }
    public List<Questions> addQuestions(List<Questions> questions){
        return questionsRepository.saveAll(questions);
    }
    public List<Questions> getQuestions(){
        return questionsRepository.findAll();
    }
    public String deleteQuestion(int id){
        questionsRepository.deleteById(id);
        return "Deleted id is "+id;
    }
    public List<Map<String,Object>> fetchRandomQuestions(List<Map<String,String>> entityObj){
        List<Map<String,Object>> questionData=new ArrayList<>();
        for(Map<String,String> obj:entityObj){
            TopicSubCategory topicSubCategory= topicSubCategoryRepository.findByTopicName(obj.get("header"));
            List<Questions> fetchQuestions=questionsRepository.fetchRandom(topicSubCategory.getId(),Integer.parseInt(obj.get("count")));
            Map<String,Object> objectMap=new HashMap<>();
            objectMap.put("topic",topicSubCategory.getTopicName());
            objectMap.put("questions",fetchQuestions);
            objectMap.put("description",topicSubCategory.getDescription());
            objectMap.put("image", topicSubCategory.getTopicImage());
            questionData.add(objectMap);
        }

        return questionData;
    }

    @Transactional
    public Questions createQuestion(Questions questions){
        String correctAnswer=questions.getCorrectAnswer();
        Integer correctAnswerId=0;
        Questions returnData=questionsRepository.saveAndFlush(questions);
        for(Options options:returnData.getOptions()){
            if(options.getOptionContent().equals(correctAnswer)){
                correctAnswerId=options.getId();
            }
        }
        if(correctAnswerId>0){
            returnData.setCorrectAnswerId(correctAnswerId);
            questionsRepository.save(returnData);
        }
        else {
            throw new RuntimeException("Option does not exist");
        }
        return returnData;
    }

    public String generateLink(List<Map<String,Object>> categoryAndCounts){
        ObjectMapper mapper=new ObjectMapper();
        try {
            String categoryAndCountsString=mapper.writeValueAsString(categoryAndCounts);
            String keyString="Idea@2022";
            String salt="mcqPassword";
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(keyString.toCharArray(), salt.getBytes(), 65536, 128);
            SecretKey secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
            String encryptedKey=encrypt(categoryAndCountsString,secretKey);
            String decryptedKey=decrypt(encryptedKey,secretKey);
            System.out.println("Encrypted -->"+encryptedKey);
            System.out.println("Decrypted -->"+decryptedKey);
            System.out.println("Secret Key -->"+secretKey);
            return encryptedKey;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Data Not Encrypted";
        }

    }

    public String encrypt(String text,SecretKey secretKey){
        try {
            Cipher cipher=Cipher.getInstance("AES");
            byte[] plainTextByte = text.getBytes();
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedByte = cipher.doFinal(plainTextByte);
            Base64.Encoder encoder = Base64.getEncoder();
            String encryptedText = encoder.encodeToString(encryptedByte);
            return encryptedText;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            return "Key Not Encrypted";
        }
    }

    public List<Map<String,Object>> fetchRandomQuestionsNew(Map<String,String> encryptedKeyText){
        try {
            String encryptedKey=encryptedKeyText.get("encryptedText");
            System.out.println(encryptedKey);
            String keyString = "Idea@2022";
            String salt = "mcqPassword";
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(keyString.toCharArray(), salt.getBytes(), 65536, 128);
            SecretKey secretKey = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
            String decryptedKey=decrypt(encryptedKey,secretKey);
            ObjectMapper mapper=new ObjectMapper();
            List<Map<String,Integer>> entityObj=mapper.readValue(decryptedKey,List.class);


            List<Map<String, Object>> questionData = new ArrayList<>();
            for (Map<String, Integer> obj : entityObj) {
                TopicSubCategory topicSubCategory = topicSubCategoryRepository.findById(obj.get("header")).orElse(null);
                List<Questions> fetchQuestions = questionsRepository.fetchRandom(obj.get("header"),obj.get("count"));
                Map<String, Object> objectMap = new HashMap<>();
                objectMap.put("topic", topicSubCategory.getTopicName());
                objectMap.put("questions", fetchQuestions);
                objectMap.put("description", topicSubCategory.getDescription());
                objectMap.put("image", topicSubCategory.getTopicImage());
                questionData.add(objectMap);
            }

            return questionData;
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            return null;
        }
    }


    public static String decrypt(String encryptedText, SecretKey secretKey)
            throws Exception {
        Cipher cipher=Cipher.getInstance("AES");
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] encryptedTextByte = decoder.decode(encryptedText);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
        String decryptedText = new String(decryptedByte);
        return decryptedText;
    }


}
