package com.example.mcqbackendapi.Service;


import com.example.mcqbackendapi.Entity.Options;
import com.example.mcqbackendapi.Repository.OptionsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OptionsService {
    @Autowired
    private OptionsRepository optionsRepository;

    public Options addOption(Options option){
        return optionsRepository.save(option);
    }
    public List<Options> addOptions(List<Options> options){
        return optionsRepository.saveAll(options);
    }
    public List<Options> getOptions(){
        return optionsRepository.findAll();
    }
    public String deleteOption(int id){
        optionsRepository.deleteById(id);
        return "Deleted id is "+id;
    }
}
