package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.TestResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TestResultRepository extends JpaRepository<TestResult,Integer> {

    @Query(value = "select * from t_testresult tr order by tr.id desc limit 10",nativeQuery = true)
    List<TestResult> findFirst10ByIdOrderByIdDesc();
}
