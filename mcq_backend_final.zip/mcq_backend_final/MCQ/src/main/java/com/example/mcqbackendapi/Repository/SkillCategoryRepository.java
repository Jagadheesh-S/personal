package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.SkillCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillCategoryRepository extends JpaRepository<SkillCategory,Integer> {
}
