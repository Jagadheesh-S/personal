package com.example.mcqbackendapi.Service;


import com.example.mcqbackendapi.Entity.TopicSubCategory;
import com.example.mcqbackendapi.Repository.TopicSubCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicSubCategoryService {
    @Autowired
    private TopicSubCategoryRepository topicSubCategoryRepository;

    public TopicSubCategory addTopicSubCategory(TopicSubCategory topicSubCategory){
        return topicSubCategoryRepository.save(topicSubCategory);
    }
    public List<TopicSubCategory> addTopicSubCategories(List<TopicSubCategory> topicSubCategories){
        return topicSubCategoryRepository.saveAll(topicSubCategories);
    }
    public List<TopicSubCategory> getTopicSubCategories(){
        return topicSubCategoryRepository.findAll();
    }
    public String deleteTopicSubCategory(int id){
        topicSubCategoryRepository.deleteById(id);
        return "Deleted id is "+id;
    }
}
