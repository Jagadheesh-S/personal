package com.example.mcqbackendapi.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "t_categorized_score")
@Entity
public class CategorizedScore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "category_score")
    private Integer categoryScore;

    @Column(name = "category_attended_questions")
    private Integer categoryAttendedQuestions;

    @Column(name = "sub_category_id")
    private Integer subCategoryId;

    @Column(name = "test_result_id")
    private Integer testResultId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "sub_category_id",referencedColumnName = "id",insertable = false,updatable = false)
    private TopicSubCategory topicSubCategory;


}
