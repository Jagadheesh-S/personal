package com.example.mcqbackendapi.Service;

import com.example.mcqbackendapi.Entity.SkillCategory;
import com.example.mcqbackendapi.Repository.SkillCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkillCategoryService {
    @Autowired
    private SkillCategoryRepository skillCategoryRepository;

    public SkillCategory addSkillCategory(SkillCategory skillCategory){
        return skillCategoryRepository.save(skillCategory);
    }
    public List<SkillCategory> addSkillCategories(List<SkillCategory> skillCategories){
        return skillCategoryRepository.saveAll(skillCategories);
    }
    public List<SkillCategory> getSkillCategories(){
        return skillCategoryRepository.findAll();
    }

    public SkillCategory fetchById(Integer id){
        return skillCategoryRepository.findById(id).orElse(null);
    }
    public String deleteSkillCategory(int id){
        skillCategoryRepository.deleteById(id);
        return "Deleted id is "+id;
    }
}
