package com.example.mcqbackendapi.Entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name="t_testresult")
public class TestResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer score;

    private String studentName;

    private String emailId;

    private String grade;

    private Double timeSpent;

    private Integer totalAttendedQuestions;

    @CreationTimestamp
    private LocalDate testDate;

    @OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    @JoinColumn(name = "test_result_id",referencedColumnName = "id")
    private List<CategorizedScore> categorizedScores;


}
