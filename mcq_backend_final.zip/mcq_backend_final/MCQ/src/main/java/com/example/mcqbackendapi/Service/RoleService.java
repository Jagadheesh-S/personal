package com.example.mcqbackendapi.Service;

import com.example.mcqbackendapi.Entity.Role;
import com.example.mcqbackendapi.Repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleService {
    @Autowired
    private RoleRepository roleRepository;

    public Role addRole(Role role){
        return roleRepository.save(role);
    }
    public List<Role> addRoles(List<Role> roles){
        return roleRepository.saveAll(roles);
    }
    public List<Role> getRoles(){
        return roleRepository.findAll();
    }
    public String deleteRole(int id){
        roleRepository.deleteById(id);
        return "Deleted id is "+id;
    }
}
