package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.SkillCategory;
import com.example.mcqbackendapi.Service.SkillCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "skillCategory/")
public class SkillCategoryController {
    @Autowired
    private SkillCategoryService skillCategoryService;

    @PostMapping("/add")
    public SkillCategory addSkillCategory(@RequestBody SkillCategory skillCategory){
        return skillCategoryService.addSkillCategory(skillCategory);
    }
    @PostMapping("/multipleAdd")
    public List<SkillCategory> addSkillCategories(@RequestBody List<SkillCategory> skillCategories){
        return skillCategoryService.addSkillCategories(skillCategories);
    }
    @GetMapping("/all")
    public List<SkillCategory> getSkillCategories(){
        return skillCategoryService.getSkillCategories();
    }
    @GetMapping("/findById")
    public SkillCategory fetchById(@RequestParam Integer id){
        return skillCategoryService.fetchById(id);
    }
    @DeleteMapping("/delete/{id}")
    public String deleteSkillCategory(@PathVariable Integer id){
        return skillCategoryService.deleteSkillCategory(id);
    }
    @PutMapping("/update")
    public SkillCategory updateSkillCategory(@RequestBody SkillCategory skillCategory){
        return skillCategoryService.addSkillCategory(skillCategory);
    }
}
