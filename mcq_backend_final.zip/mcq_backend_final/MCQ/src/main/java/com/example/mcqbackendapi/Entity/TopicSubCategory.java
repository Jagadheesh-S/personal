package com.example.mcqbackendapi.Entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name="m_topic_subcategory")
public class TopicSubCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String topicName;
    @Formula("(select count(mq.id) from m_question mq where mq.topic_id=id)")
    private Integer questionCount;

    private String description;

    @Column(name="skill_category_id")
    private Integer skillCategoryId;

    @Column(columnDefinition = "LONGTEXT",name = "topicImage")
    private String topicImage;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "skill_category_id",referencedColumnName = "id",insertable = false,updatable = false)
    private SkillCategory skillCategory;

    @JsonIgnore
    public SkillCategory getSkillCategory() {
        return skillCategory;
    }

}
