package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.TestResult;
import com.example.mcqbackendapi.Service.TestResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "testResult/")
public class TestResultController {

    @Autowired
    private TestResultService testResultService;

    @PostMapping("/submitResult")
    public ResponseEntity<Object> submitResult(@RequestParam List<Integer> questionsIds,@RequestParam List<Integer> answerIds,@RequestParam String studentName,@RequestParam String emailId,@RequestParam String timeSpent,@RequestParam List<Integer> categories){
        return ResponseEntity.ok().body(testResultService.submitResult(questionsIds, answerIds, studentName, emailId, timeSpent,categories));
    }

    @GetMapping("/getResults")
    public List<TestResult> viewResult(){
        return testResultService.viewTestResults();
    }

    @GetMapping("/findLastTenRecords")
    public List<TestResult> fetchLast10Records(){
        return testResultService.findLastTenRecords();
    }
}
