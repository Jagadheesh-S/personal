package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.Options;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OptionsRepository extends JpaRepository<Options,Integer> {

    Options findByOptionContent(String optionContent);
}
