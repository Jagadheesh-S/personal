package com.example.mcqbackendapi.Service;

import com.example.mcqbackendapi.Entity.CategorizedScore;
import com.example.mcqbackendapi.Entity.Questions;
import com.example.mcqbackendapi.Entity.TestResult;
import com.example.mcqbackendapi.Repository.QuestionsRepository;
import com.example.mcqbackendapi.Repository.TestResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TestResultService {
    @Autowired
    private QuestionsRepository questionsRepository;
    @Autowired
    private TestResultRepository testResultRepository;

    public TestResult submitResult(List<Integer> questionIds,List<Integer> answerIds,String studentName,String emailId,String timeSpent,List<Integer> categories){

        List<Questions> questions=questionsRepository.findAllById(questionIds);
        List<CategorizedScore> categorizedScores=new ArrayList<>();
        TestResult testResult=new TestResult();
        testResult.setTotalAttendedQuestions(questions.size());
        Integer totalScore=0;
        for(Integer category:categories) {
            Integer score=0;
            CategorizedScore categorizedScore=new CategorizedScore();
            List<Questions> categoryBased=questions.stream().filter(e->e.getTopicId()==category||e.getTopicId().equals(category)).collect(Collectors.toList());
            for (Integer answer : answerIds) {
                for (Questions question : categoryBased) {
                    Integer answerInQuestion = question.getCorrectAnswerId();
                    if (answer.equals(answerInQuestion) || answer == answerInQuestion) {
                        score++;
                        totalScore++;
                    }
                }
            }
            categorizedScore.setSubCategoryId(category);
            categorizedScore.setCategoryScore(score);
            categorizedScore.setCategoryAttendedQuestions(categoryBased.size());
            categorizedScores.add(categorizedScore);
        }
        testResult.setScore(totalScore);
        testResult.setEmailId(emailId);
        testResult.setStudentName(studentName);
        testResult.setTimeSpent(Double.parseDouble(timeSpent));
        testResult.setCategorizedScores(categorizedScores);
        Double calc= Double.valueOf(Double.valueOf(totalScore)/Double.valueOf(questions.size()));
        Double percentage= Double.valueOf(calc*100);
        if(percentage>=40){
            testResult.setGrade("Pass");
        }
        else {
            testResult.setGrade("Fail");
        }
        testResultRepository.save(testResult);

        return testResult;

    }

    public List<TestResult> viewTestResults(){
        return testResultRepository.findAll();
    }

    public List<TestResult> findLastTenRecords(){
        return testResultRepository.findFirst10ByIdOrderByIdDesc();
    }

}
