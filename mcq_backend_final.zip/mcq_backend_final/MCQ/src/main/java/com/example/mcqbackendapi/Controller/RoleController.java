package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.Role;
import com.example.mcqbackendapi.Service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "role/")
public class RoleController {
    @Autowired
    private RoleService roleService;

    @PostMapping("/add")
    public Role addRole(@RequestBody Role role){
        return roleService.addRole(role);
    }
    @PostMapping("/multipleAdd")
    public List<Role> addRoles(@RequestBody List<Role> roles){
        return roleService.addRoles(roles);
    }
    @GetMapping("/all")
    public List<Role> getRoles(){
        return roleService.getRoles();
    }
    @DeleteMapping("/delete/{id}")
    public String deleteRole(@PathVariable Integer id){
        return roleService.deleteRole(id);
    }
    @PutMapping("/update")
    public Role updateRole(@RequestBody Role role){
        return roleService.addRole(role);
    }
}
