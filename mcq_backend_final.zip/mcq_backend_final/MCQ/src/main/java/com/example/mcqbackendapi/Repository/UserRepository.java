package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Integer> {
        User findByEmailAndPassword(String email,String Password);
        User findByEmail(String email);
        User findByUsername(String username);
        User findByPassword(String password);
        User findByRoleId(Integer roleId);
}
