package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.Questions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QuestionsRepository extends JpaRepository<Questions,Integer> {

    @Query(value = "select * from m_question m where m.topic_id=:topicId order by rand() limit :noOfQuestions",nativeQuery = true)
    List<Questions> fetchRandom(Integer topicId,Integer noOfQuestions);

}
