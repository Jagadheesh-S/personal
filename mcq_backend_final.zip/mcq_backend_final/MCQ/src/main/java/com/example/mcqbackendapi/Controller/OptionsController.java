package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.Options;
import com.example.mcqbackendapi.Service.OptionsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "options/")
public class OptionsController {
    @Autowired
    private OptionsService optionsService;

    @PostMapping("/add")
    public Options addOption(@RequestBody Options option){
        return optionsService.addOption(option);
    }
    @PostMapping("/multipleAdd")
    public List<Options> addOptions(@RequestBody List<Options> options){
        return optionsService.addOptions(options);
    }
    @GetMapping("/all")
    public List<Options> getOptions(){
        return optionsService.getOptions();
    }
    @DeleteMapping("/delete/{id}")
    public String deleteOption(@PathVariable Integer id){
        return optionsService.deleteOption(id);
    }
    @PutMapping("/update")
    public Options updateOption(@RequestBody Options option){
        return optionsService.addOption(option);
    }
}
