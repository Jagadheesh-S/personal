package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {
}
