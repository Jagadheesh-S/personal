package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.TopicSubCategory;
import com.example.mcqbackendapi.Service.TopicSubCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "topicSubCategory/")
public class TopicSubCategoryController {
    @Autowired
    private TopicSubCategoryService topicSubCategoryService;

    @PostMapping("/add")
    public TopicSubCategory addTopicSubCategory(@RequestBody TopicSubCategory topicSubCategory){
        return topicSubCategoryService.addTopicSubCategory(topicSubCategory);
    }
    @PostMapping("/multipleAdd")
    public List<TopicSubCategory> addTopicSubCategories(@RequestBody List<TopicSubCategory> topicSubCategories){
        return topicSubCategoryService.addTopicSubCategories(topicSubCategories);
    }
    @GetMapping("/all")
    public List<TopicSubCategory> getTopicSubCategories(){
        return topicSubCategoryService.getTopicSubCategories();
    }
    @DeleteMapping("/delete/{id}")
    public String deleteTopicSubCategory(@PathVariable Integer id){
        return topicSubCategoryService.deleteTopicSubCategory(id);
    }
    @PutMapping("/update")
    public TopicSubCategory updateTopicSubCategory(@RequestBody TopicSubCategory topicSubCategory){
        return topicSubCategoryService.addTopicSubCategory(topicSubCategory);
    }
}
