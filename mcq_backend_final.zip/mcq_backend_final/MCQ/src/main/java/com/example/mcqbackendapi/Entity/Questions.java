package com.example.mcqbackendapi.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Formula;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name="m_question")
public class Questions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String question;

    @Column(name = "correct_answer_id")
    private Integer correctAnswerId;

    @Column(name = "topic_id")
    private Integer topicId;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="question_id",referencedColumnName = "id")
    private List<Options> options;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "topic_id",referencedColumnName = "id",insertable = false,updatable = false)
    private TopicSubCategory topicSubCategory;


    //public String correctAnswer;

    @Transient
    public String correctAnswer;

}
