package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.Questions;
import com.example.mcqbackendapi.Service.QuestionsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "questions/")
public class QuestionsController {
    @Autowired
    private QuestionsService questionsService;

    @PostMapping("/add")
    public Questions addQuestion(@RequestBody Questions question){
        return questionsService.addQuestion(question);
    }
    @PostMapping("/multipleAdd")
    public List<Questions> addQuestions(@RequestBody List<Questions> questions){
        return questionsService.addQuestions(questions);
    }
    @GetMapping("/all")
    public List<Questions> getQuestions(){
        return questionsService.getQuestions();
    }
    @DeleteMapping("/delete/{id}")
    public String deleteQuestion(@PathVariable Integer id){
        return questionsService.deleteQuestion(id);
    }
    @PutMapping("/update")
    public Questions updateQuestion(@RequestBody Questions option){
        return questionsService.addQuestion(option);
    }
    @PostMapping("/fetchRandomQuestions")
    public List<Map<String,Object>> fetchRandomQuestions(@RequestBody List<Map<String,String>> entityObj){
        return questionsService.fetchRandomQuestions(entityObj);
    }
    @PostMapping("/createQuestion")
    public Questions createQuestion(@RequestBody Questions questions){
        return questionsService.createQuestion(questions);
    }

    @PostMapping("/generateLink")
    public String generateLink(@RequestBody List<Map<String,Object>> categoryAndCount){
        return questionsService.generateLink(categoryAndCount);
    }

    @PostMapping("/fetchRandomQuestionsNew")
    public List<Map<String,Object>> fetchRandomQuestionsNew(@RequestBody Map<String,String> encryptedText){
        return questionsService.fetchRandomQuestionsNew(encryptedText);
    }

}
