package com.example.mcqbackendapi.Service;

import com.example.mcqbackendapi.Entity.User;
import com.example.mcqbackendapi.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public ResponseEntity<Object> RegisterUser(User user){
        User existingUserByEmail=userRepository.findByEmail(user.getEmail());
        User existingUserByUserName=userRepository.findByUsername(user.getUsername());
        if(existingUserByEmail!=null){
            return ResponseEntity.badRequest().body("Email Already Exists");
        }
        else if(existingUserByUserName!=null){
            return ResponseEntity.badRequest().body("Username Already Exists");
        }
        else {
            user.setRoleId(1);
            return ResponseEntity.ok().body(userRepository.save(user));
        }
    }
    public ResponseEntity<Object> addUser(User user){
        User existingUserByEmail=userRepository.findByEmail(user.getEmail());
        User existingUserByUserName=userRepository.findByUsername(user.getUsername());
        if(existingUserByEmail!=null){
            return ResponseEntity.badRequest().body("Email Already Exists");
        }
        else if(existingUserByUserName!=null){
            return ResponseEntity.badRequest().body("Username Already Exists");
        }
        else {
            return ResponseEntity.ok().body(userRepository.save(user));
        }
    }
    public List<User> addUsers(List<User> users){
        return userRepository.saveAll(users);
    }
    public List<User> getUsers(){
        return userRepository.findAll();
    }
    public String deleteUser(int id){
        userRepository.deleteById(id);
        return "Deleted id is "+id;
    }
    public ResponseEntity<Object> login(User user) {
        User existingUser = userRepository.findByEmailAndPassword(user.getEmail(),user.getPassword());
        if (existingUser == null) {
            if (userRepository.findByEmail(user.getEmail()) == null) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Email does not exist");
            }
            else if (userRepository.findByPassword(user.getPassword()) == null) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Incorrect Password");
            }
            else {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Email or Password Incorrect");
            }
        }
        else {
            return ResponseEntity.status(HttpStatus.OK).body(existingUser.getRole().getRoleName()+"User Logged in Successfully");
        }
    }
}
