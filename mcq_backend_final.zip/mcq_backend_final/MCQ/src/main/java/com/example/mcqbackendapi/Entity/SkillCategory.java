package com.example.mcqbackendapi.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
@Table(name="m_skill_category")
public class SkillCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String skillCategoryName;

    @OneToMany(mappedBy = "skillCategory",cascade = CascadeType.ALL)
    private List<TopicSubCategory> topicSubCategories;


}
