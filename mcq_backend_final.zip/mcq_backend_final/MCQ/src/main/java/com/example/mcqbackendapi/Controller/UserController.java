package com.example.mcqbackendapi.Controller;

import com.example.mcqbackendapi.Entity.User;
import com.example.mcqbackendapi.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "user/")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/add")
    public ResponseEntity<Object> addUser(@RequestBody User user){
        return userService.addUser(user);}
    @PostMapping("/multipleAdd")
    public List<User> addUsers(@RequestBody List<User> users){
        return userService.addUsers(users);}
    @GetMapping("/all")
    public List<User> getUsers(){
        return userService.getUsers();
    }
    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable Integer id){
        return userService.deleteUser(id);
    }
    @PutMapping("/update")
    public ResponseEntity<Object> updateUser(@RequestBody User user){
        return userService.addUser(user);
    }
    @PostMapping("/login")
    public ResponseEntity<Object> login(@RequestBody User user){
        return userService.login(user);
    }

    @PostMapping("/demo")
    public ResponseEntity<Object> demo(@RequestParam List<Integer> ids){
        return ResponseEntity.ok().body(ids);
    }
}
