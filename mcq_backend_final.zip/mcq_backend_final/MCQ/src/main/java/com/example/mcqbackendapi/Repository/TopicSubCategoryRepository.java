package com.example.mcqbackendapi.Repository;

import com.example.mcqbackendapi.Entity.TopicSubCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TopicSubCategoryRepository extends JpaRepository<TopicSubCategory,Integer> {

    TopicSubCategory findByTopicName(String topicName);
}
