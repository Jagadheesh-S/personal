package com.example.mcqbackendapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McqBackendApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
